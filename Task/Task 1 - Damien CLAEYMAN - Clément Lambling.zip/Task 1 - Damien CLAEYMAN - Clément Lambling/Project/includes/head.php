<meta charset="UTF-8">
<title>Alzheimer center</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo getRoot()?>css/style.css">

